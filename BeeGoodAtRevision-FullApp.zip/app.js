function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const stored = localStorage.getItem(email);
  if (stored && JSON.parse(stored).password === password) {
    localStorage.setItem('loggedIn', email);
    window.location.href = 'dashboard.html';
  } else {
    alert('Invalid login!');
  }
}

function signup() {
  const email = document.getElementById('newEmail').value;
  const password = document.getElementById('newPassword').value;
  const profileColor = '#' + Math.floor(Math.random()*16777215).toString(16);
  localStorage.setItem(email, JSON.stringify({password, profileColor}));
  alert('Signed up! Now log in.');
}

function showSignup() {
  document.getElementById('signup').style.display = 'block';
}

function logout() {
  localStorage.removeItem('loggedIn');
  window.location.href = 'index.html';
}

function toggleMusic() {
  const music = document.getElementById('bg-music');
  if (music.paused) {
    music.play();
  } else {
    music.pause();
  }
}